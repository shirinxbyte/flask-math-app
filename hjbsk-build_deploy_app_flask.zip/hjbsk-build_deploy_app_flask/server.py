from flask import Flask, render_template, request

# Import math functions (make sure this matches your file structure)
try:
    from Maths.mathematics import summation, subtraction, multiplication
except ImportError:
    # Fallback in case of import issues
    def summation(a, b): return a + b
    def subtraction(a, b): return a - b
    def multiplication(a, b): return a * b

app = Flask(__name__)

# Homepage
@app.route("/")
def home():
    """Render the main index page"""
    return render_template("index.html")

# Addition
@app.route("/sum")
def add():
    """Handle addition requests"""
    try:
        num1 = float(request.args.get('num1', 0))  # Default to 0 if missing
        num2 = float(request.args.get('num2', 0))
        return str(summation(num1, num2))
    except ValueError:
        return "Error: Please enter valid numbers (e.g., /sum?num1=5&num2=3)"

# Subtraction
@app.route("/sub")
def subtract():
    """Handle subtraction requests"""
    try:
        num1 = float(request.args.get('num1', 0))
        num2 = float(request.args.get('num2', 0))
        return str(subtraction(num1, num2))
    except ValueError:
        return "Error: Please enter valid numbers (e.g., /sub?num1=5&num2=3)"

# Multiplication
@app.route("/mul")
def multiply():
    """Handle multiplication requests"""
    try:
        num1 = float(request.args.get('num1', 0))
        num2 = float(request.args.get('num2', 0))
        return str(multiplication(num1, num2))
    except ValueError:
        return "Error: Please enter valid numbers (e.g., /mul?num1=5&num2=3)"

if __name__ == "__main__":
    print("🔄 Starting server...")  # Debug message
    app.run(host="0.0.0.0", port=8080, debug=True)
    print("🚀 Server is running!")  # Debug message